<?php
if(isset($_POST['Register']))
{
  
  $Username = mysqli_real_escape_string($conn,$_POST['Username']);
  $Email = mysqli_real_escape_string($conn,$_POST["Email"]);
  $password = mysqli_real_escape_string($conn,$_POST['password']);
  $Confirm_password = mysqli_real_escape_string($conn,$_POST['Confirm_password']);

  $pass = password_hash($password, PASSWORD_BCRYPT);
  $Cpass = password_hash($Confirm_password, PASSWORD_BCRYPT);

  $Emailquery =  "SELECT * FROM registerdata WHERE Email = '$Email' ";
  $query = mysqli_query($conn, $Emailquery);

  // $Emailcount = mysqli_num_rows($query);
  $Emailcount = mysqli_fetch_array($query);


  if($Emailcount > 0)
  {
    echo "email already exists";
  }
  else{
    if($password === $Confirm_password)
    {
      $insertquery = "INSERT INTO registerdata  (Username,Email, Password, Confirm_Password) values('$Username','$Email','$pass','$Cpass')";

      $iquery  = mysqli_query($conn,$insertquery);

      if($iquery){
        echo "<script>alert('Connection Successfully ');</script>";
            
       }
       else{
        echo "<script>alert('No Connection ');</script>";
   }
    } else{
      echo "<script>alert('Password are not matching');</script>";
      
       }
  }
}
?>
  <?php
                    $sel = "SELECT * FROM registerdata";
                    $query = mysqli_query($conn,$sel);
                    $result = mysqli_fetch_assoc($query);
                      ?>
                    <h5> <?php echo isset($_SESSION['Username']); ?></h5>


