
<?php 
include("contactConnection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6 Part(C)_Contact_Us.html</title>
    <link rel="stylesheet" href="Contact_Us.css">
</head>
<body>
    <header>
        <div class="MainContainer">
            <div class="mainbox navibox1">
             <img src="logo.png" alt="">
            </div>
            <div class="mainbox navibox2">
                <ul>
                    <a href="Home_Page.php"><li>Home</li></a>
                    <a href="Check_Appoinment.php"><li>Check Appoinment</li></a>
                    <a href="About_Us.php"><li>About Us</li></a>
                    <a href="Contact_Us.php"><li>Contact Us</li></a>
                </ul>
            </div>
            <div class="Box_form">          
                <h1>Contact  Us</h1><br>
                <div>
                    <form action="#" method="POST">
                      <label for="fname">First Name</label>
                      <input type="text" id="fname" name="firstname" placeholder="Your name..">
                  
                      <label for="lname">Email-Id</label>
                      <input type="text" id="lname" name="Email" placeholder="Your Email-Id..">

                      <label for="lname">Phone number:</label><br>
                   <input type="tel" id="phone" name="number" placeholder="123-45-678">
                  
                   <label for="lname">Massage :</label><br><br>
                   <textarea id="text" name="massage"rows="4" cols="20">
                   Enter text here...
                   </textarea>

                      <input type="submit" value="Submit">
                    </form>
                  </div>

            </div>
    </header>
  
</body>
</html>


<?php

if(isset($_POST['Submit']))
  {
  $firstname = mysqli_real_escape_string($conn,$_POST['firstname']);
  $Email = mysqli_real_escape_string($conn,$_POST['Email']);
  $Number = mysqli_real_escape_string($conn,$_POST['number']);
  $massage = mysqli_real_escape_string($conn,$_POST['massage']);

  $query = "INSERT INTO FORM contactdetail(firstname,Email,number,massage) VALUES($firstname,$Email,$Number,$massage)";
   $Data = mysqli_query($conn,$query);
  if($Data)
  {
    echo "Your contact detail Successfully submitted:";
    }

  else{ 
    echo "Failed";

  }
}
  
?>
