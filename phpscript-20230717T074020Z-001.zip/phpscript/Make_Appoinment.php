<!-- 
//session_start();
if// (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
  //header("location:login.php");
//exit;
}
?> -->

<?php 
include("connectionpage.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Make_Appoinment.css">
</head>
<body>
<header>
<div class="MainContainer">
            <div class="mainbox navibox1">
             <img src="logo.png" alt="">
            </div>
            <div class="mainbox navibox2">
                <ul>
                    <a href="Home_Page.php"><li>Home</li></a>
                    <a href="Check_Appoinment.php"><li>Check Appoinment</li></a>
                    <a href="About_Us.php"><li>About Us</li></a>
                    <a href="Contact_Us.php"><li>Contact Us</li></a>
                </ul>
            </div>
  </header>
  <h2>Book <span>Appointment</span></h2>
  <div class="container">
  <form action="#" method="POST">
  <div>
      <label>Does you visit here First time ?</label>
      <input class="w3-radio" type="radio" name="question" value="Yes" checked>
      <label>Yes</label>
      <input class="w3-radio" type="radio" name="question" value="No">
      <label>No</label>
  </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name :</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="firstname" placeholder="Your name..">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name :</label>
      </div>
      <div class="col-75">
        <input type="text" id="lname" name="lastname" placeholder="Your last name..">
      </div>
      </div>
    <div class="row">
        <div class="col-25">
        <label for="phone">Enter a phone number:</label>
    </div>
    <div class="col-75">
        <input type="tel" id="phone" name="Number" placeholder="123-45-678"><br>
    </div>
    
        <label>Gender : </label>
        <input class="w3-radio" type="radio" name="gender" value="male" checked>
        <label>Male</label>
        <input class="w3-radio" type="radio" name="gender" value="female">
        <label>Female</label>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label for="Physician"> Select Physician :</label>
      </div>
      <div class="col-75">
        <select id="Physician" name="Physician">
            <option value=" select Now">Select Now</option>
          <option value="Dr.S.k Saxena">Dr.S.k Saxena</option>
          <option value=" Dr. Megha Saxena"> Dr. Megha Saxena</option>
          <option value=" Dr. Kshitish Saxena"> Dr. Kshitish Saxena</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="Consultancy Department">Consultancy Department :</label>
      </div>
      <div class="col-75">
        <select id="Consultancy Department" name="ConsultancyDepartment">
            <option value=" select Now">Select Now</option>
          <option value="ENT Otolaryngologist">ENT Otolaryngologist</option>
          <option value=" Homeopathy Doctor"> Homeopathy Doctor</option>
          <option value=" Ophthalmologist"> Ophthalmologist</option>
        </select>
      </div>
    </div>

    <div class="row">
        <div class="col-25">
          <label for="address">Address :</label>
        </div>
        <div class="col-75">
          <input type="text" id="address" name="address" placeholder="write your address..">
        </div>
      </div>
      
      <div class="row">
        <div class="col-25">
          <label for=" Confirm address"> Confirm address :</label>
        </div>
     
        <div class="col-75">
          <input type="text" id=" confirmaddress" name=" confirmaddress" placeholder="write your address..">
        </div>
      </div>
     
      <div class="row">
        <div class="col-25">
          <label for="Date">Appoinment Date:</label>
        </div>
        <div class="col-75">
          <input type="date" id="Date" name="Date">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
      <label for="appt">Appoinment Select a time:</label>
        </div>
        <div class="col-75">
          <input type="time" id="appt" name="appt">
        </div>
      </div>
     

    <div class="row">
      <div class="col-25">
        <label for="Describe your problem">Describe your problem :</label>
      </div>
      <div class="col-75">
        <textarea id="Describe your problem" name="Describeyourproblem" placeholder="Please describe Your problem in detail here.." style="height:200px"></textarea>
      </div>
    </div>
   
    <div class="row">
      <input type="submit" value = "Book Appoinment" name ="BookAppoinment" >
    </div>
     
    <div class="row">
      <input type="reset" value="Reset" name = "reset">
    </div>
  </form>
</div>
<div class="DEVLOPER">
        Copyright &copy; www.DoctorAppointment.com. All rights reserved!
      </div>
</body>
</html>

<?php
if(isset($_POST['BookAppoinment']))
  {
  $Question = $_POST['question'];
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $Number = $_POST['Number'];
  $gender = $_POST['gender'];
  $Physician = $_POST['Physician'];
  $ConsultancyDepartment = $_POST['ConsultancyDepartment'];
  $address = $_POST['address'];
  $confirmaddress = $_POST['confirmaddress'];
  $Date = $_POST['Date'];
  $appt = $_POST['appt'];
  
  $Describeyourproblem = $_POST['Describeyourproblem'];

  if($Question != "" && $firstname != "" && $lastname != "" && $Number != "" && $gender != "" && $Physician != "" && $ConsultancyDepartment != "" && $address != "" && $confirmaddress != "" && $Date != "" && $appt != "" && $Describeyourproblem != "")
{

  $query = "INSERT INTO appoinmentformdata (Question,Firstname,lastname,Number,gender,Physician,ConsultancyDepartment,address,confirmaddress,Date,Time,Describeyourproblem) VALUES('$Question','$firstname','$lastname','$Number','$gender','$Physician','$ConsultancyDepartment','$address','$confirmaddress','$Date','$appt','$Describeyourproblem')";
$Data = mysqli_query($conn,$query);
  if($Data)
  {
// Fetch data using primary key
$primaryKey = "id"; // Replace with your primary key value
$sql = "SELECT * FROM appoinmentformdata WHERE id = $primaryKey";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row["id"]; // Assuming "id" is one of the columns in your table
         // Display data in an alert
            echo "<script>alert('Appointment ID: $id');</script>";
    }

  }
  else{ 
    echo "Failed";

  }
}
}
else{
       echo "<script>alert('Please Fill The Form First');</script>";
  }
}

?>
