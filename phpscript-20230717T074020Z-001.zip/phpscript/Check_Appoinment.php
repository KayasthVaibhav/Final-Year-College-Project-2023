<?php
//session_start();
//if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
 // header("location:login.php");
//exit;
//}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Check_Appoinment.css">
</head>
<body>
<header>
<div class="MainContainer">
            <div class="mainbox navibox1">
             <img src="logo.png" alt="">
            </div>
            <div class="mainbox navibox2">
                <ul>
                    <a href="Home_Page.php"><li>Home</li></a>
                    <a href="Check_Appoinment.php"><li>Check Appoinment</li></a>
                    <a href="About_Us.php"><li>About Us</li></a>
                    <a href="Contact_Us.php"><li>Contact Us</li></a>
                </ul>
            </div>
  </header>
<h2>Check <span>Appointment</span></h2>

<div class="container">
<form action="#" method="POST">
    <div class="row">
      <div class="col-25">
        <label for="fname">Enter Appoinment_Id :</label>
      </div>
      <div class="col-75">
        <input type="text" name="get_id" class="form-control" placeholder="Enter Id.." required>
      </div>
    </div>
    </div>
    <div class="row">
      <button type="submit" name="search_by_id" class="btn btn-primary">Check Appoinment</button> 
    </div> 
  </form>
  
</div> 

<br><br>
<?php
include('connectionpage.php');
if(isset($_POST['search_by_id']))
{
 $id = $_POST['get_id'];
 $result = mysqli_query($conn,"SELECT * FROM `appoinmentformdata` WHERE `id`= '$id'");      

?>
<!-- Data base fatch from the Main Database in table -->
<center><table class="table table-bordered" border = "1px solid black" cellspacing = "7" width = "1%">
  <h1 style="border: 1 solid black; background-color: black;  color: white;"> Here it's Your Booking Appoinment Details </h1>
  
  <thead >
    <tr>
      <th width = "3%" scope="col">Id</th>
      <th width = "2%" scope="col">Question</th>
      <th width = "10%" scope="col">Firstname</th>
      <th width = "10%" scope="col">Lastname</th>  
      <th width = "5%" scope="col">Number</th>
      <th width = "4%" scope="col">Gender</th>
      <th width = "10%" scope="col">Physician</th>
      <th width = "10%" scope="col">ConsultancyDepartment</th>
      <th width = "10%" scope="col">Address</th>
      <th width = "10%" scope="col">ConfirmAddress</th>
      <th width = "8%" scope="col">Date</th>
      <th width = "6%" scope="col">Appoinment-Time</th>
      <th width = "10%" scope="col">Describeyourproblem</th>
    </tr>
  </thead>
  
  <tbody>
    <?php
           if(mysqli_num_rows($result) > 0){
            while($data = mysqli_fetch_assoc($result))
              {
    ?>
    <tr>
      <th scope="row">1</th>
      <td><?php echo $data["Question"]; ?></td>
      <td><?php echo $data["Firstname"]; ?></td>
      <td><?php echo $data["lastname"]; ?></td>
      <td><?php echo $data["Number"]; ?></td>
      <td><?php echo $data["gender"]; ?></td>
      <td><?php echo $data["Physician"]; ?></td>
      <td><?php echo $data["ConsultancyDepartment"]; ?></td>
      <td><?php echo $data["address"]; ?></td>
      <td><?php echo $data["confirmaddress"]; ?></td>
      <td><?php echo $data["Date"]; ?></td>
      <td><?php echo $data["Time"]; ?></td>
      <td><?php echo $data["Describeyourproblem"]; ?></td>
    </tr>  
    <?php
 }
}
else{
 ?>
 <tr>
  <td>No Record Found</td>
 </tr>
 <?php
}
?>
  </tbody>
</table>

</center>

<?php
}
?>
</body>
</html>

