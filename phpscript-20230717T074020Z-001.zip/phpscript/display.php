<?php
include("connection.php");
$sql = "SELECT Question, Firstname, lastname ,Number ,gender,Physician ,ConsultancyDepartment ,address ,confirmaddress ,Date,appt,Describeyourproblem FROM appoinmentformdata";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<br> Question: " . $row["Question"]. " <br> First Name: " . $row['Firstname']. " <br> Last Name: " . $row["lastname"]." <br> Gender: ".$row['gender']. "  <br>Number: " . $row["Number"]. "  <br>Consultancy Department: " . $row['ConsultancyDepartment']. " <br> Physician:" . $row['Physician']. "<br> address:" . $row['address']. " <br> confirmaddress:" . $row['confirmaddress']. "<br> Date:" . $row['Date']. " <br> Appoinmen-Time : " .$row['appt']. " <br> Describe your problem : " .$row['Describeyourproblem']. " ";    
  }
} else {
  echo "0 results";
}
$conn->close();
?>

