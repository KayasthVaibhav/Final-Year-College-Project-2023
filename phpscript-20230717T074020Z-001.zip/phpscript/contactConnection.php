<?php
$servername = "localhost";

$username = "root";

$password = "";

$dbname = "contactform";

 $conn = mysqli_connect($servername,$username,$password,$dbname);

 if($conn){
  
  echo  "Connetion successufllly ";

 }
 else{
    echo  "No connection ";
}
?>