<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6 Part(C) _About_Us.html</title>
    <link rel="stylesheet" href="About_Us.css">
</head>
<body>
    <header>
        <div class="MainContainer">
            <div class="mainbox navibox1">
             <img src="logo.png" alt="">
            </div>
            <div class="mainbox navibox2">
                <ul>
                   <a href="Home_Page.php"><li>Home</li></a>
                    <a href="Check_Appoinment.php"><li>Check Appoinment</li></a>
                    <a href="About_Us.php"><li>About Us</li></a>
                    <a href="Contact_Us.php"><li>Contact Us</li></a>
                </ul>
            </div>
        </header>
        <section>
            <div class="MainContainer1">
                <div class="Paragraph">
                    <h1>Best Experienced Faculties</h1>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolor eaque amet quibusdam, repudiandae natus recusandae, voluptatem sed omnis, unde vel culpa ipsa a odit. Lorem ipsum dolor sit amet. Lorem ipsum dolor sit, amet consectetur adipisicing.</p>
                </div>
                <div class="BottomBox">
                    <div class="BottomBox Box1">
                        <ul>
                            <li class="smallLi">20+</li>
                            <li>Doctors</li>
                        </ul>
                    </div>
                    <div class="BottomBox Box2">
                        <ul>
                            <li class="smallLi">50,000+</li>
                            <li>Customers</li>
                        </ul>
                    </div>
                    <div class="BottomBox Box3">
                        <ul>
                            <li class="smallLi">500+</li>
                            <li>Students</li>
                        </ul>
                    </div>
                </div>
        </div>
    </section>
 
</body>
</html>