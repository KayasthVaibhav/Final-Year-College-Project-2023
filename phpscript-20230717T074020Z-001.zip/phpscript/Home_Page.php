<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project 6 Part(C) HTML_CSS Project_Style (HOME PAGE)</title>
    <link rel="stylesheet" href="Home_Page.css">
    <!-- <link rel="stylesheet" href=""> -->
</head>
<body>
    <header>
        <div class="MainContainer">
            <div class="mainbox navibox1">
             <img src="logo.png" alt="">
            </div>
            <div class="mainbox navibox2">
                <ul>
                    <a href="Home_Page.php"><li>Home</li></a>
                    <a href="Check_Appoinment.php"><li>Check Appoinment</li></a>
                    <a href="About_Us.php"><li>About Us</li></a>
                    <a href="Contact_Us.php"><li>Contact Us</li></a>
                    <a href="Login.php"><li> Logged Out</li></a>
                </ul>
            </div>
            <div class="mainbox navibox3">
                
                
                <div class="topAngleimage">                    
                </div>
                <div class="bottomAngleimage">                    
                </div>
             <div class="Heading">
                 <h1>Complete health <br>Care Solutions For <br> Everyone</h1>
             </div>   
             <div class="Paragraph">
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi ab aspernatur fuga deserunt molestias omnis.</p>
                </div>
                <div class="Button">
                <a href="Make_Appoinment.php">
                <button>Make Appointment</button></a>
             </div>
             <div class="mouse">
                <img src="mouse.png" alt="">
            </div>   
            </div>
            <div class="mainbox navibox4">
                <div class="DoctorBox">
                    <img src="doctor.png" alt="">
               </div>   
                <div class="yellowBox">
                    </div>
            </div>
        </div>
     
    </header>
    <br><br><br>

    </div> 
    <div class="DEVLOPER">
        Copyright &copy; www.DoctorAppointment.com. All rights reserved!
    </div>
</body>
</html>
