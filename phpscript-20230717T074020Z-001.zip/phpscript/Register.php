<!DOCTYPE html>
<?php
include('connection.php');
if(isset($_POST['Register']))
{
   
  $Username = mysqli_real_escape_string($conn,$_POST['Username']);
  $Email = mysqli_real_escape_string($conn,$_POST["Email"]);
  $password = mysqli_real_escape_string($conn,$_POST['password']);
  $Confirm_password = mysqli_real_escape_string($conn,$_POST['Confirm_password']);
  if(empty($Username))
  {
    $error = "Username field is required";
  }
  else if(empty($Email))
  {
    $error = "Email field is required";
  }
  else if(empty($password))
  {
    $error = "password field is required";
  }
  else if($password != $Confirm_password)
  {
    $error = "Password does not Match";
  }

else if(strlen($password)<6)
  {
    $error = "Password must be atleast 6 Character";
  }
  else{
    
$Emailquery = "SELECT * FROM registerdata  WHERE  Email = '$Email'";
$query = mysqli_query($conn,$Emailquery);
$Emailcount = mysqli_num_rows($query);
if($Emailcount>0)
{
    echo " email already exists";
}else{
   $insertquery =  "INSERT INTO registerdata(Username, Email, password, Confirm_Password) VALUES ('$Username','$Email','$password','$Confirm_password')";
   
   $iquery = mysqli_query($conn,$insertquery);

   if($conn){
    echo "<script>alert('Your Account has been successufully Created');</script>";  
}
else{
       echo "<script>alert('Account Creation Failed');</script>";  
    }
  }
    }
  }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Now</title>
    <link rel="stylesheet" href="Register.css">
</head>
<body>
    <div class="Register">
     <p style = "color: red">
        <?php
     if(isset($error)){
        echo $error ;
    }
        ?>

     </p>
  
    <form action="#" method="Post">
    <div class="center">
        <h1><img src="PateintImage (2).png" alt=""><br><br><br>Register Now</h1>
        <input type = "text" name = "Username" class="textfiled" placeholder="Username" value = "<?php
             if(isset($error)){
                echo $Username;
                }
        ?>">
        <input type = "email" name = "Email" class="textfiled" placeholder="Email-Id"
        value = "<?php
             if(isset($error)){
                echo $Email;
                }
        ?>">
        <input type = "password" name = "password" class="textfiled" placeholder="Create password ">
        <input type = "password" name = "Confirm_password" class="textfiled" placeholder="Confirm password ">
        <!-- <div class="forgetpass"><a href="#" class="links">forget password ?</a></div> -->
        <input type="submit" value = "Register" name ="Register" class="btn">
        <!-- <input type="submit" name="Registerhere" value="Register" class="btn"> -->

        <div class="signup">New Member ? &nbsp;<a href="Login.php" class="link">Login Here</a></div>
        </div>
        </form> 
        </div>
</body>
</html>
<!-- // echo htmlentities($_SERVER['PHP_SELF']); -->

