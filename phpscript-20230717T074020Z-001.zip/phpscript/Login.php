<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login BY cyber warriour</title>
        <link rel="stylesheet" href="Login.css">
    </head>
    <body>
        <form action="#" method="POST">
            <div class="center">
                <h1><img src="PateintImage (2).png" alt=""><br><br><br>Login Now</h1>
                <input type = "email" name = "Email" class="textfiled" placeholder="Username ">
        <input type = "password" name = "password" class="textfiled" placeholder="password ">

        <div class="forgetpass"><a href="#" class="links">forget password ?</a></div>
        
        <input type="submit" name="Login" value="Login" class="btn">
        
        <div class="signup">New Member ? &nbsp;<a href="Register.php" class="link">Register Here</a></div>
    </div>
    </div>
    </form>
</body>
</html>
<?php

include('connection.php');
//sign in 
if (isset($_POST['Login'])) {
    $email = $_POST['Email'];
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM `registerdata` WHERE Email='$email' AND password ='$password'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_array($result);
    $_SESSION['name'] = $username;
    if (mysqli_num_rows($result) > 0)
    {
        if (mysqli_num_rows($result) == 1) {
            $name = $data['username'];
      

            header('Location: ../phpscript/Home_Page.php');

        }
    } else {
        echo "Incorrect email or password";
    }
}


?>